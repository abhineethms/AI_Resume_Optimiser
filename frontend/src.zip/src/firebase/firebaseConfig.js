// Import the Firebase SDK functions
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getStorage } from 'firebase/storage';
import { getFirestore } from 'firebase/firestore';

// Firebase configuration from your project settings
const firebaseConfig = {
  apiKey: "AIzaSyC6IySfqg-aVsr06MswU87MHxSSV9o3QlE",
  authDomain: "resume-jd-matcher-18f9b.firebaseapp.com",
  projectId: "resume-jd-matcher-18f9b",
  storageBucket: "resume-jd-matcher-18f9b.firebasestorage.app",
  messagingSenderId: "426082155927",
  appId: "1:426082155927:web:80eb812c38a7b70b6bd8d2",
  measurementId: "G-3RYDFM70H8"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase services
const auth = getAuth(app);
const storage = getStorage(app);
const db = getFirestore(app);

// Configure persistence (optional)
// setPersistence(auth, browserLocalPersistence);

// Export the Firebase instances
export { app, auth, storage, db };